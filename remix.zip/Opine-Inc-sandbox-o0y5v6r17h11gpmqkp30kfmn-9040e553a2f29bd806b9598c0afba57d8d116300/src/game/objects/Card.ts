
// src/game/objects/Card.ts

import { Scene } from 'phaser'
import { Upgrade } from '../config/upgrades'
import { COLORS } from '../config/constants'

export class Card extends Phaser.GameObjects.Container {
  private background: Phaser.GameObjects.Graphics
  private titleText: Phaser.GameObjects.Text
  private descText: Phaser.GameObjects.Text
  private upgrade: Upgrade
  private isHovered: boolean = false

  constructor(scene: Scene, x: number, y: number, upgrade: Upgrade) {
    super(scene, x, y)
    this.upgrade = upgrade
    
    // Card background
    this.background = scene.add.graphics()
    this.background.fillStyle(COLORS.UI_DARK)
    this.background.fillRoundedRect(-120, -80, 240, 160, 10)
    this.background.lineStyle(3, upgrade.color)
    this.background.strokeRoundedRect(-120, -80, 240, 160, 10)
    this.add(this.background)
    
    // Title
    this.titleText = scene.add.text(0, -40, upgrade.name, {
      fontSize: '18px',
      color: '#ffffff',
      align: 'center',
      wordWrap: { width: 220 }
    })
    this.titleText.setOrigin(0.5)
    this.add(this.titleText)
    
    // Description
    this.descText = scene.add.text(0, 10, upgrade.description, {
      fontSize: '14px',
      color: '#cccccc',
      align: 'center',
      wordWrap: { width: 220 }
    })
    this.descText.setOrigin(0.5)
    this.add(this.descText)
    
    // Rarity indicator
    const rarityColor = this.getRarityColor(upgrade.rarity)
    const rarityBg = scene.add.graphics()
    rarityBg.fillStyle(rarityColor)
    rarityBg.fillRoundedRect(-60, 50, 120, 20, 5)
    this.add(rarityBg)
    
    const rarityText = scene.add.text(0, 60, upgrade.rarity.toUpperCase(), {
      fontSize: '12px',
      color: '#ffffff',
      align: 'center'
    })
    rarityText.setOrigin(0.5)
    this.add(rarityText)
    
    // Add to scene first
    scene.add.existing(this)
    
    // Set up interaction with proper bounds - use a simpler approach
    this.setSize(240, 160)
    this.setInteractive()
    this.setupInteractions()
  }

  private getRarityColor(rarity: string): number {
    switch (rarity) {
      case 'common': return 0x888888
      case 'rare': return 0x0088ff
      case 'epic': return 0x8800ff
      case 'legendary': return 0xff8800
      default: return 0x888888
    }
  }

  private setupInteractions() {
    this.on('pointerover', () => {
      this.isHovered = true
      this.setScale(1.05)
      this.background.clear()
      this.background.fillStyle(COLORS.UI_LIGHT)
      this.background.fillRoundedRect(-120, -80, 240, 160, 10)
      this.background.lineStyle(4, this.upgrade.color)
      this.background.strokeRoundedRect(-120, -80, 240, 160, 10)
    })
    
    this.on('pointerout', () => {
      this.isHovered = false
      this.setScale(1)
      this.background.clear()
      this.background.fillStyle(COLORS.UI_DARK)
      this.background.fillRoundedRect(-120, -80, 240, 160, 10)
      this.background.lineStyle(3, this.upgrade.color)
      this.background.strokeRoundedRect(-120, -80, 240, 160, 10)
    })
    
    this.on('pointerdown', (pointer: Phaser.Input.Pointer) => {
      // Prevent event bubbling
      pointer.event.stopPropagation()
      
      console.log('Card clicked:', this.upgrade.name)
      const scene = this.scene as any
      if (scene.selectUpgrade) {
        scene.selectUpgrade(this.upgrade)
      }
    })
    
    // Add visual feedback for clicks
    this.on('pointerup', () => {
      if (this.isHovered) {
        this.setScale(1.05)
      } else {
        this.setScale(1)
      }
    })
  }
}
