
// src/game/utils/UIManager.ts

import { Scene } from 'phaser'
import { COLORS, GAME_CONFIG } from '../config/constants'

export class UIManager {
  private scene: Scene
  private player: any
  private gameTime: number = 0
  
  // UI Elements
  private healthBar!: Phaser.GameObjects.Graphics
  private xpBar!: Phaser.GameObjects.Graphics
  private levelText!: Phaser.GameObjects.Text
  private timeText!: Phaser.GameObjects.Text
  private roundText!: Phaser.GameObjects.Text
  private enemyCountText!: Phaser.GameObjects.Text

  constructor(scene: Scene, player: any) {
    this.scene = scene
    this.player = player
  }

  public createUI(uiCamera: Phaser.Cameras.Scene2D.Camera): void {
    const cornerX = 5
    const cornerY = 5
    
    this.levelText = this.scene.add.text(cornerX, cornerY, 'Level: 1', {
      fontSize: '16px',
      color: '#ffffff',
      backgroundColor: 'rgba(0,0,0,0.9)',
      padding: { x: 6, y: 3 }
    })
    this.levelText.setOrigin(0, 0)
    this.levelText.setDepth(1000)
    
    this.timeText = this.scene.add.text(cornerX, cornerY + 25, 'Time: 0:00', {
      fontSize: '14px',
      color: '#ffffff',
      backgroundColor: 'rgba(0,0,0,0.9)',
      padding: { x: 6, y: 3 }
    })
    this.timeText.setOrigin(0, 0)
    this.timeText.setDepth(1000)
    
    this.roundText = this.scene.add.text(cornerX, cornerY + 50, 'Round: 1', {
      fontSize: '16px',
      color: '#ffff00',
      backgroundColor: 'rgba(0,0,0,0.9)',
      padding: { x: 6, y: 3 }
    })
    this.roundText.setOrigin(0, 0)
    this.roundText.setDepth(1000)
    
    this.enemyCountText = this.scene.add.text(cornerX, cornerY + 75, 'Enemies: 0/10', {
      fontSize: '14px',
      color: '#ff6666',
      backgroundColor: 'rgba(0,0,0,0.9)',
      padding: { x: 6, y: 3 }
    })
    this.enemyCountText.setOrigin(0, 0)
    this.enemyCountText.setDepth(1000)
    
    this.healthBar = this.scene.add.graphics()
    this.healthBar.setDepth(1000)
    
    this.xpBar = this.scene.add.graphics()
    this.xpBar.setDepth(1000)
    
    // Make main camera ignore UI elements
    this.scene.cameras.main.ignore([
      this.levelText, 
      this.timeText, 
      this.roundText, 
      this.enemyCountText, 
      this.healthBar, 
      this.xpBar
    ])
  }

  public updateUI(gameTime: number, currentRound: number, enemiesKilled: number, enemiesNeeded: number): void {
    this.gameTime = gameTime
    
    const cornerX = 5
    const cornerY = 5
    const barWidth = 150
    const barHeight = 12
    const healthBarY = cornerY + 100
    const xpBarY = cornerY + 116
    
    // Clear and redraw health bar
    this.healthBar.clear()
    this.healthBar.fillStyle(COLORS.UI_DARK)
    this.healthBar.fillRoundedRect(cornerX, healthBarY, barWidth, barHeight, 3)
    this.healthBar.fillStyle(COLORS.DANGER)
    const healthPercent = this.player.health / this.player.maxHealth
    this.healthBar.fillRoundedRect(cornerX + 2, healthBarY + 2, (barWidth - 4) * healthPercent, barHeight - 4, 2)
    
    // Clear and redraw XP bar
    this.xpBar.clear()
    this.xpBar.fillStyle(COLORS.UI_DARK)
    this.xpBar.fillRoundedRect(cornerX, xpBarY, barWidth, barHeight, 3)
    this.xpBar.fillStyle(COLORS.ACCENT)
    const xpNeeded = GAME_CONFIG.LEVELING.BASE_XP * Math.pow(GAME_CONFIG.LEVELING.XP_MULTIPLIER, this.player.level - 1)
    const xpPercent = this.player.xp / xpNeeded
    this.xpBar.fillRoundedRect(cornerX + 2, xpBarY + 2, (barWidth - 4) * xpPercent, barHeight - 4, 2)
    
    // Update text content
    this.levelText.setText(`Level: ${this.player.level}`)
    
    const minutes = Math.floor(gameTime / 60000)
    const seconds = Math.floor((gameTime % 60000) / 1000)
    this.timeText.setText(`Time: ${minutes}:${seconds.toString().padStart(2, '0')}`)
    
    this.roundText.setText(`Round: ${currentRound}`)
    this.enemyCountText.setText(`Enemies: ${enemiesKilled}/${enemiesNeeded}`)
  }

  public showRoundComplete(currentRound: number, enemiesKilled: number, enemiesNeeded: number, totalKills: number): Phaser.GameObjects.Container {
    const gameWidth = this.scene.sys.game.config.width as number
    const gameHeight = this.scene.sys.game.config.height as number
    
    const roundCompleteOverlay = this.scene.add.container(0, 0)
    roundCompleteOverlay.setScrollFactor(0)
    roundCompleteOverlay.setDepth(2500)
    
    const overlay = this.scene.add.graphics()
    overlay.fillStyle(0x000000, 0.6)
    overlay.fillRect(0, 0, gameWidth, gameHeight)
    roundCompleteOverlay.add(overlay)
    
    const title = this.scene.add.text(gameWidth / 2, gameHeight / 2 - 50, `ROUND ${currentRound} COMPLETE!`, {
      fontSize: '48px',
      color: '#00ff00',
      align: 'center',
      fontStyle: 'bold'
    })
    title.setOrigin(0.5)
    roundCompleteOverlay.add(title)
    
    const statsText = this.scene.add.text(gameWidth / 2, gameHeight / 2 + 20, [
      `Enemies Defeated: ${enemiesKilled}/${enemiesNeeded}`,
      `Total Kills: ${totalKills}`,
      `Preparing Round ${currentRound + 1}...`
    ], {
      fontSize: '20px',
      color: '#ffffff',
      align: 'center',
      lineSpacing: 8
    })
    statsText.setOrigin(0.5)
    roundCompleteOverlay.add(statsText)
    
    this.scene.cameras.main.ignore([roundCompleteOverlay, overlay, title, statsText])
    
    return roundCompleteOverlay
  }

  public destroy(): void {
    if (this.healthBar) this.healthBar.destroy()
    if (this.xpBar) this.xpBar.destroy()
    if (this.levelText) this.levelText.destroy()
    if (this.timeText) this.timeText.destroy()
    if (this.roundText) this.roundText.destroy()
    if (this.enemyCountText) this.enemyCountText.destroy()
  }
}
